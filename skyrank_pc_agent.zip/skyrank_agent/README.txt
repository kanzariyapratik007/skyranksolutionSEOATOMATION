=================================================================
  SkyRank Local PC Agent - 1-Click Automated Setup
=================================================================

Step 1: Extract this ZIP folder to your Desktop or any folder.

Step 2: Double-click 'run_local_agent.bat'.
        (It will automatically install Python and dependencies if needed)
        (Keep the black terminal window open/minimized while posting)

Step 3: Open your web portal:
        http://52.55.247.39/submission-manager.php

Step 4: The badge will show '🟢 PC Agent: Connected (Your PC)'.
        Select your project/keyword and click 'Auto Post'!
=================================================================
