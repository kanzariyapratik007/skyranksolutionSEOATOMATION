=================================================================
  SkyRank Local PC Agent - Setup Guide
=================================================================

Step 1: Extract this ZIP folder to your Desktop or any folder.

Step 2: Double-click 'run_local_agent.bat' to start the agent.
        (Keep the black terminal window open/minimized while posting)

Step 3: Open your web portal in any browser:
        http://52.55.247.39/submission-manager.php

Step 4: The badge will show '🟢 PC Agent: Connected (Your PC)'.
        Select your project/keyword and click 'Auto Post'!

=================================================================
Note: Ensure Google Chrome and Python are installed on your PC.
=================================================================
