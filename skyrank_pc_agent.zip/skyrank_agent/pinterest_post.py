#!/usr/bin/env python3
"""
Pinterest Auto-Post via Selenium — v4 Final
Verified selectors from live page inspection on kanzariyapratik124@gmail.com
"""
import sys, json, time, os, re
script_dir = os.path.dirname(os.path.abspath(__file__))
try:
    import pwd
    sys_user = pwd.getpwuid(os.getuid())[0]
except Exception:
    import getpass
    sys_user = getpass.getuser()
app_tmp_dir = os.path.join(script_dir, f'tmp_dir_{sys_user}')
try:
    os.makedirs(app_tmp_dir, exist_ok=True)
except Exception:
    pass
os.environ['HOME'] = app_tmp_dir
os.environ['WDM_LOG'] = '0'
os.environ['WDM_DIR'] = os.path.join(app_tmp_dir, '.wdm')
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

def log(msg):
    print(json.dumps({"log": msg}), flush=True)

def result(success, url='', error=''):
    print(json.dumps({"success": success, "url": url, "error": error}), flush=True)

def get_driver(email="default", proxy=None):
    opts = Options()
    if sys.platform != "win32":
        opts.add_argument('--headless=new')
        opts.add_argument('--disable-gpu')
        opts.add_argument('--disable-software-rasterizer')
        opts.add_argument('--disable-setuid-sandbox')
        opts.add_argument('--disable-namespace-sandbox')
        import shutil
        chrome_bin = shutil.which('google-chrome') or shutil.which('google-chrome-stable') or shutil.which('chromium-browser') or shutil.which('chromium')
        if not chrome_bin:
            for b in ['/usr/bin/google-chrome', '/usr/bin/google-chrome-stable', '/usr/bin/chromium-browser', '/usr/bin/chromium', '/snap/bin/chromium']:
                if os.path.exists(b):
                    chrome_bin = b
                    break
        if chrome_bin:
            opts.binary_location = chrome_bin

    # Chrome launch flags optimized for Linux EC2 stability with strict RAM limits
    opts.add_argument('--no-sandbox')
    opts.add_argument('--disable-dev-shm-usage')
    opts.add_argument('--disable-gpu')
    opts.add_argument('--disable-software-rasterizer')
    opts.add_argument('--js-flags=--max-old-space-size=512')
    opts.add_argument('--disk-cache-size=1')
    opts.add_argument('--media-cache-size=1')
    opts.add_argument('--disable-site-isolation-trials')
    opts.add_argument('--disable-features=IsolateOrigins,site-per-process,MediaRouter,Translate')
    opts.add_argument('--disable-blink-features=AutomationControlled')
    opts.add_argument('--disable-extensions')
    opts.add_experimental_option('excludeSwitches', ['enable-automation'])
    opts.add_experimental_option('useAutomationExtension', False)
    opts.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36')
    opts.add_argument('--window-size=1280,900')
    opts.add_argument('--disable-breakpad')
    opts.add_argument('--disable-crash-reporter')

    proxy_url = proxy or os.environ.get('PINTEREST_PROXY')
    if proxy_url:
        log(f"Using proxy: {proxy_url}")
        opts.add_argument(f'--proxy-server={proxy_url}')

    import hashlib, getpass, zipfile
    email_hash = hashlib.md5(email.lower().encode('utf-8')).hexdigest()
    profile_base = '/tmp' if sys.platform != 'win32' else script_dir
    profile_dir = os.path.join(profile_base, f'chrome_profile_pinterest_{email_hash}')
    os.makedirs(profile_dir, mode=0o777, exist_ok=True)
    try:
        os.chmod(profile_dir, 0o777)
    except Exception:
        pass

    target_default = os.path.join(profile_dir, 'Default')
    zip_path = os.path.join(script_dir, 'pinterest_cookies.zip')
    if "newlmt97" in email.lower() and (not os.path.exists(target_default) or not os.listdir(target_default)) and os.path.exists(zip_path):
        try:
            log("Restoring saved login session cookies from pinterest_cookies.zip...")
            os.makedirs(target_default, mode=0o777, exist_ok=True)
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(target_default)
            log("Session cookies successfully restored!")
        except Exception as e_zip:
            log(f"Cookie restore error: {e_zip}")

    # Clean up lock files and any leftover Chrome processes on Linux
    if sys.platform != "win32":
        try:
            os.system("pkill -9 -f chrome 2>/dev/null; pkill -9 -f chromedriver 2>/dev/null")
            time.sleep(0.5)
        except Exception:
            pass

    if os.path.exists(profile_dir):
        for root, dirs, files in os.walk(profile_dir):
            for f in files:
                if f in ["SingletonLock", "SingletonCookie", "SingletonSocket", "lock", "DevToolsActivePort"]:
                    p = os.path.join(root, f)
                    try:
                        if os.path.islink(p):
                            os.unlink(p)
                        else:
                            os.remove(p)
                    except:
                        pass

    opts.add_argument(f'--user-data-dir={profile_dir}')
    import shutil
    sys_chromedriver = shutil.which('chromedriver') or ('/usr/bin/chromedriver' if os.path.exists('/usr/bin/chromedriver') else None)
    
    driver = None
    last_err = ""
    for attempt in range(3):
        if os.path.exists(profile_dir):
            for root, dirs, files in os.walk(profile_dir):
                for f in files:
                    if f in ["SingletonLock", "SingletonCookie", "SingletonSocket", "lock", "DevToolsActivePort"]:
                        p = os.path.join(root, f)
                        try:
                            if os.path.islink(p):
                                os.unlink(p)
                            else:
                                os.remove(p)
                        except Exception:
                            pass
        try:
            # 1. Try standard Selenium Manager auto-resolution first
            driver = webdriver.Chrome(options=opts)
        except Exception as e_mgr:
            last_err = str(e_mgr)
            log(f"Selenium Manager launch attempt {attempt+1} failed: {e_mgr}")
            if sys_chromedriver:
                try:
                    service = Service(sys_chromedriver)
                    driver  = webdriver.Chrome(service=service, options=opts)
                except Exception as e_sys:
                    last_err = str(e_sys)
                    log(f"System chromedriver attempt {attempt+1} failed: {e_sys}")

        if driver:
            break

        # Fallback profile directory on subsequent attempt if profile dir was locked
        if attempt == 1:
            import tempfile
            fallback_dir = tempfile.mkdtemp(prefix="chrome_fb_")
            opts = Options()
            if sys.platform != "win32":
                opts.add_argument('--headless=new')
                opts.add_argument('--disable-gpu')
                opts.add_argument('--disable-software-rasterizer')
                opts.add_argument('--disable-setuid-sandbox')
                opts.add_argument('--disable-namespace-sandbox')
            opts.add_argument('--no-sandbox')
            opts.add_argument('--disable-dev-shm-usage')
            opts.add_argument('--disable-blink-features=AutomationControlled')
            opts.add_experimental_option('excludeSwitches', ['enable-automation'])
            opts.add_experimental_option('useAutomationExtension', False)
            opts.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36')
            opts.add_argument('--window-size=1920,1080')
            opts.add_argument(f'--user-data-dir={fallback_dir}')

        time.sleep(2)

    if not driver:
        log(f"All Chrome launch attempts failed. Details: {last_err}")
        return None

    try:
        driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
            "source": """
                Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
                Object.defineProperty(navigator, 'languages', {get: () => ['en-US', 'en']});
                Object.defineProperty(navigator, 'plugins', {get: () => [1, 2, 3, 4, 5]});
                Object.defineProperty(navigator, 'hardwareConcurrency', {get: () => 8});
                window.chrome = { runtime: {} };
                const originalQuery = window.navigator.permissions.query;
                if (originalQuery) {
                    window.navigator.permissions.query = (parameters) => (
                        parameters.name === 'notifications' ?
                        Promise.resolve({ state: Notification.permission }) :
                        originalQuery(parameters)
                    );
                }
            """
        })
    except Exception as e:
        pass
    return driver

def js_click(driver, el):
    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", el)
    time.sleep(0.3)
    driver.execute_script("arguments[0].click();", el)

def js_set_value(driver, el, value):
    """React-compatible value setter supporting input, textarea, and contenteditable elements"""
    driver.execute_script("""
        var el = arguments[0], val = arguments[1];
        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
            el.focus();
            var proto = (el.tagName === 'TEXTAREA') ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
            var descriptor = Object.getOwnPropertyDescriptor(proto, 'value');
            if (descriptor && descriptor.set) {
                try { descriptor.set.call(el, val); } catch(e) { el.value = val; }
            } else {
                el.value = val;
            }
            if (el._valueTracker) {
                el._valueTracker.setValue('');
            }
            el.dispatchEvent(new Event('input', {bubbles: true, composed: true}));
            el.dispatchEvent(new Event('change', {bubbles: true, composed: true}));
            el.dispatchEvent(new Event('blur', {bubbles: true, composed: true}));
        } else {
            try { el.innerText = val; } catch(e) { el.textContent = val; }
            el.dispatchEvent(new Event('input', {bubbles: true, composed: true}));
        }
    """, el, value)

def set_input_value(driver, el, value):
    js_set_value(driver, el, value)

def set_system_clipboard(text):
    """Sets text to OS clipboard across Windows and Linux platforms."""
    if not text:
        return False
    # Method 1: Windows ctypes win32 API
    try:
        import ctypes
        CF_UNICODETEXT = 13
        GMEM_MOVEABLE = 0x0002
        if ctypes.windll.user32.OpenClipboard(None):
            ctypes.windll.user32.EmptyClipboard()
            utf16_bytes = text.encode('utf-16le') + b'\x00\x00'
            h_mem = ctypes.windll.kernel32.GlobalAlloc(GMEM_MOVEABLE, len(utf16_bytes))
            if h_mem:
                p_mem = ctypes.windll.kernel32.GlobalLock(h_mem)
                if p_mem:
                    ctypes.cdll.msvcrt.memcpy(ctypes.c_void_p(p_mem), utf16_bytes, len(utf16_bytes))
                    ctypes.windll.kernel32.GlobalUnlock(h_mem)
                    ctypes.windll.user32.SetClipboardData(CF_UNICODETEXT, h_mem)
            ctypes.windll.user32.CloseClipboard()
            return True
    except Exception:
        pass

    # Method 2: Windows clip command
    try:
        import subprocess
        p = subprocess.Popen(['clip'], stdin=subprocess.PIPE, shell=True)
        p.communicate(input=text.encode('utf-16le'))
        return True
    except Exception:
        pass

    # Method 3: Linux xclip
    try:
        import subprocess
        p = subprocess.Popen(['xclip', '-selection', 'clipboard'], stdin=subprocess.PIPE)
        p.communicate(input=text.encode('utf-8'))
        return True
    except Exception:
        pass

    return False

def fill_draftjs_editor(driver, text):
    """Option 1: Accurately fills Pinterest DraftJS description with placeholder activation, OS clipboard paste, synthetic fallback, and 1.5s React state commit pause."""
    if not text:
        return False

    # 1. Set OS clipboard immediately
    set_system_clipboard(text)

    # 2. Step A: Check and click any description placeholder or expander button
    activator_selectors = [
        "button[aria-label*='description' i]",
        "button[aria-label*='Tell' i]",
        "[data-test-id='pin-builder-description'] button",
        "[data-test-id='pin-builder-description'] [role='button']",
        "[data-test-id='description-field'] button",
        "[data-test-id='pin-builder-description']",
        "[data-test-id='description-field']"
    ]
    for act_sel in activator_selectors:
        try:
            btns = driver.find_elements(By.CSS_SELECTOR, act_sel)
            for btn in btns:
                if btn.is_displayed():
                    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", btn)
                    time.sleep(0.2)
                    driver.execute_script("arguments[0].click();", btn)
                    time.sleep(0.4)
                    break
        except Exception:
            pass

    # 3. Step B: Locate the active DraftJS contenteditable or textarea
    desc_el = None
    selectors = [
        "[data-test-id='pin-builder-description'] [contenteditable='true']",
        "[data-test-id='pin-builder-description'] .public-DraftEditor-editor [contenteditable='true']",
        "[data-test-id='pin-builder-description'] .public-DraftEditor-editor",
        "[data-test-id='pin-builder-description'] div[role='textbox']",
        "[data-test-id='description-field'] [contenteditable='true']",
        ".public-DraftEditor-editor [contenteditable='true']",
        ".public-DraftEditor-editor",
        "div[contenteditable='true'][role='textbox']",
        "div.notranslate[contenteditable='true']",
        "#storyboard-selector-description",
        "[data-test-id='pin-builder-description'] textarea",
        "textarea[placeholder*='description' i]",
        "textarea[placeholder*='Tell' i]"
    ]
    for sel in selectors:
        els = driver.find_elements(By.CSS_SELECTOR, sel)
        for el in els:
            if el.is_displayed():
                desc_el = el
                break
        if desc_el:
            break

    if not desc_el:
        try:
            elems = driver.find_elements(By.CSS_SELECTOR, "textarea, div[contenteditable='true'], div[role='textbox']")
            for c in elems:
                if not c.is_displayed():
                    continue
                ph = (c.get_attribute('placeholder') or '').lower()
                aria = (c.get_attribute('aria-label') or '').lower()
                dt = (c.get_attribute('data-test-id') or '').lower()
                if 'title' in aria or 'title' in ph:
                    continue
                if any(w in ph or w in aria or w in dt for w in ['description', 'tell', 'add', 'detail']):
                    desc_el = c
                    break
        except Exception:
            pass

    if not desc_el:
        log("DraftJS description element not found via selectors")
        return False

    log("Found DraftJS description element — activating and pasting text...")

    # Focus and scroll element into view
    try:
        driver.execute_script("arguments[0].scrollIntoView({block:'center'}); arguments[0].focus();", desc_el)
        time.sleep(0.3)
    except Exception:
        pass

    # Real user click to establish focus inside DraftJS
    try:
        ActionChains(driver).move_to_element(desc_el).click().perform()
        time.sleep(0.3)
    except Exception:
        try:
            desc_el.click()
            time.sleep(0.3)
        except Exception:
            pass

    # Select all and paste via Ctrl+V (DraftJS handlePastedText handler)
    try:
        ActionChains(driver).key_down(Keys.CONTROL).send_keys('a').key_up(Keys.CONTROL).perform()
        time.sleep(0.2)
        ActionChains(driver).send_keys(Keys.BACKSPACE).perform()
        time.sleep(0.2)
        ActionChains(driver).key_down(Keys.CONTROL).send_keys('v').key_up(Keys.CONTROL).perform()
        time.sleep(0.8)
    except Exception as e_ac:
        log(f"Ctrl+V paste error: {e_ac}")

    cur_text = (desc_el.text or desc_el.get_attribute('value') or '').strip()
    if not cur_text:
        log("Direct Ctrl+V paste empty, injecting via DraftJS synthetic events + execCommand...")
        try:
            driver.execute_script("""
                var el = arguments[0], val = arguments[1];
                el.focus();
                try {
                    var dt = new DataTransfer();
                    dt.setData('text/plain', val);
                    var pasteEvt = new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: dt });
                    el.dispatchEvent(pasteEvt);
                } catch(e) {}
                try {
                    document.execCommand('selectAll', false, null);
                    document.execCommand('insertText', false, val);
                } catch(e) {}
                el.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true, inputType: 'insertText', data: val }));
                el.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
            """, desc_el, text)
            time.sleep(0.8)
        except Exception as e_synth:
            log(f"Synthetic paste note: {e_synth}")

    # React State Commit: 1.5s Pause + slight micro-keystroke to seal DraftJS state
    time.sleep(1.5)
    try:
        ActionChains(driver).send_keys(Keys.SPACE).send_keys(Keys.BACKSPACE).perform()
        time.sleep(0.3)
    except Exception:
        pass

    final_text = (desc_el.text or desc_el.get_attribute('value') or '').strip()
    log(f"DraftJS Description state committed: {len(final_text)} chars")
    return True

def safe_get(driver, url, max_retries=3, delay=3):
    urls_to_try = [url]
    if "www.pinterest.com" in url:
        urls_to_try.append(url.replace("www.pinterest.com", "in.pinterest.com"))
    elif "in.pinterest.com" in url:
        urls_to_try.append(url.replace("in.pinterest.com", "www.pinterest.com"))

    for target_url in urls_to_try:
        for i in range(max_retries):
            try:
                log(f"Navigating to {target_url} (Attempt {i+1}/{max_retries})...")
                driver.get(target_url)
                time.sleep(delay)
                current = (driver.current_url or '').lower()
                page_src = (driver.page_source or '').lower()
                if "neterror" not in current and "chrome-error" not in current and "err_name_not_resolved" not in page_src:
                    return True
                log(f"DNS/Network note on {target_url}, trying fallback...")
                time.sleep(delay)
            except Exception as e:
                log(f"Navigation attempt {i+1} failed: {e}")
                time.sleep(delay)
    return False

def pinterest_post(email, password, keyword, target_site, image_path=None, ai_title="", ai_content="", proxy=None):
    log(f"Starting Pinterest post with email: {email}")
    driver = get_driver(email, proxy=proxy)
    if not driver:
        result(False, error="Failed to launch Chrome driver on server")
        return
    wait = WebDriverWait(driver, 25)

    try:
        log("Opening Pinterest...")
        if not safe_get(driver, "https://www.pinterest.com/pin-builder/"):
            log("Initial pin-builder navigation returned error — retrying main page...")
            safe_get(driver, "https://www.pinterest.com/")
            time.sleep(3)

        current = driver.current_url.lower()
        needs_login = ("login" in current or "signup" in current or len(driver.find_elements(By.CSS_SELECTOR, "input#email, input[type='email'], input[name='id']")) > 0)

        if needs_login:
            log("Not logged in — navigating to login page...")
            if "login" not in current:
                safe_get(driver, "https://www.pinterest.com/login/")
                time.sleep(3)

            log("Locating email input...")
            email_field = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "input#email, input[type='email'], input[name='id'], input[name='username']")))
            driver.execute_script("arguments[0].scrollIntoView({block:'center'}); arguments[0].focus();", email_field)
            time.sleep(0.2)
            try:
                email_field.clear()
            except Exception:
                pass
            for ch in str(email):
                email_field.send_keys(ch)
                time.sleep(0.02)
            js_set_value(driver, email_field, email)
            time.sleep(0.3)

            log("Locating password input...")
            pass_field = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "input#password, input[type='password'], input[name='password']")))
            driver.execute_script("arguments[0].scrollIntoView({block:'center'}); arguments[0].focus();", pass_field)
            time.sleep(0.2)
            try:
                pass_field.clear()
            except Exception:
                pass
            for ch in str(password):
                pass_field.send_keys(ch)
                time.sleep(0.02)
            js_set_value(driver, pass_field, password)
            time.sleep(0.5)

            log("Clicking Login button...")
            driver.execute_script("""
                var emailInp = document.querySelector("input#email, input[type='email'], input[name='id'], input[name='username']");
                var passInp = document.querySelector("input#password, input[type='password'], input[name='password']");
                var btn = document.querySelector("[data-test-id='registerFormSubmitButton'], button[type='submit']");
                if (!btn) {
                    var btns = Array.from(document.querySelectorAll('button'));
                    btn = btns.find(function(b) {
                        var t = (b.innerText || b.textContent || '').trim().toLowerCase();
                        return t === 'log in' || t === 'login';
                    });
                }
                if (btn) {
                    btn.disabled = false;
                    btn.removeAttribute('disabled');
                    btn.scrollIntoView({block: 'center'});
                    btn.click();
                }
                var form = (passInp ? passInp.closest('form') : null) || document.querySelector("form");
                if (form) {
                    try { form.dispatchEvent(new Event('submit', {bubbles: true, cancelable: true})); } catch(e) {}
                }
            """)
            time.sleep(0.3)
            try:
                pass_field.send_keys(Keys.ENTER)
            except Exception:
                pass

            log("Waiting for authentication redirect...")
            time.sleep(4)
            is_authed = False
            for _ in range(12):
                try:
                    curr = driver.current_url.lower()
                    if "login" not in curr and "signup" not in curr and "pinterest" in curr:
                        is_authed = True
                        log(f"Login success! Redirected to: {driver.current_url}")
                        break
                except Exception:
                    pass
                time.sleep(1.5)

            if not is_authed:
                err_text = f"Pinterest login failed on AWS — URL: {driver.current_url}"
                try:
                    page_text = driver.find_element(By.TAG_NAME, "body").text
                    log(f"Page text sample: {page_text[:300].replace(chr(10), ' ')}")
                    if "strange activity" in page_text.lower() or "reset your password" in page_text.lower():
                        err_text = "Pinterest Account Security Lock: 'We noticed some strange activity on your account. Please reset your password on Pinterest.'"
                    elif "incorrect" in page_text.lower() or "invalid" in page_text.lower():
                        err_text = "Pinterest Login Failed: Incorrect password or email for this account."
                except Exception:
                    pass
                try:
                    driver.save_screenshot(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'pinterest_error.png'))
                    log("Saved login failure screenshot to pinterest_error.png")
                except Exception:
                    pass
                try:
                    driver.quit()
                except Exception:
                    pass
                try:
                    import shutil
                    if os.path.exists(profile_dir):
                        shutil.rmtree(profile_dir, ignore_errors=True)
                        log("Cleared failed login profile for clean retry.")
                except Exception:
                    pass
                result(False, error=err_text)
                return

        log("Login OK!")

        # ── Step 2: Pin Creation Tool & Drafts Purge ──────────────
        if "pin-builder" not in driver.current_url.lower():
            log("Opening Pin creation tool (pin-builder)...")
            safe_get(driver, "https://www.pinterest.com/pin-builder/")
            time.sleep(5)
        
        # Purge any old leftover drafts so the new Pin is 100% the ONLY Pin being published
        try:
            log("Checking for existing leftover drafts to clear...")
            # 1. Try Select All checkbox + Delete button
            driver.execute_script("""
                var cbs = Array.from(document.querySelectorAll("input[type='checkbox']"));
                for (var cb of cbs) {
                    var parentText = (cb.parentElement ? cb.parentElement.innerText : '').toLowerCase();
                    var aria = (cb.getAttribute('aria-label') || '').toLowerCase();
                    if (parentText.includes('select all') || aria.includes('select all')) {
                        if (!cb.checked) { cb.click(); }
                        break;
                    }
                }
            """)
            time.sleep(1)
            
            deleted_any = driver.execute_script("""
                var delBtns = Array.from(document.querySelectorAll("button, div[role='button']"));
                for (var b of delBtns) {
                    var txt = (b.innerText || b.getAttribute('aria-label') || '').trim().toLowerCase();
                    if (txt === 'delete' || txt === 'delete draft' || txt === 'delete drafts' || txt === 'discard') {
                        b.click();
                        return true;
                    }
                }
                return false;
            """)
            if deleted_any:
                time.sleep(1.5)
                # Confirm popup if present
                driver.execute_script("""
                    var confirmBtns = Array.from(document.querySelectorAll("div[role='dialog'] button, div[data-test-id*='modal'] button, div[role='dialog'] div[role='button']"));
                    for (var b of confirmBtns) {
                        var txt = (b.innerText || b.getAttribute('aria-label') || '').trim().toLowerCase();
                        if (txt === 'delete' || txt === 'yes, delete' || txt === 'confirm') {
                            b.click();
                            break;
                        }
                    }
                """)
                time.sleep(2)
                log("Deleted leftover drafts via Select All -> Delete.")
            
            # 2. Check if 3-dots menus exist on individual draft items to delete one-by-one
            for _ in range(5):
                dots_menu_clicked = driver.execute_script("""
                    var draftsPanel = document.querySelector("div[aria-label*='Pin drafts' i], div[data-test-id*='drafts' i]");
                    var dots = Array.from((draftsPanel || document).querySelectorAll("button[aria-label*='More' i], button[aria-label*='Options' i], div[data-test-id*='overflow' i] button, button[aria-label*='draft' i]"));
                    for (var d of dots) {
                        if (d.offsetParent !== null) {
                            d.click();
                            return true;
                        }
                    }
                    return false;
                """)
                if dots_menu_clicked:
                    time.sleep(0.8)
                    driver.execute_script("""
                        var menuItems = Array.from(document.querySelectorAll("div[role='menu'] div[role='button'], div[role='menu'] button, div[data-test-id*='menu'] button"));
                        for (var item of menuItems) {
                            var t = (item.innerText || '').toLowerCase();
                            if (t.includes('delete') || t.includes('discard')) {
                                item.click();
                                break;
                            }
                        }
                    """)
                    time.sleep(1)
                    driver.execute_script("""
                        var confs = Array.from(document.querySelectorAll("div[role='dialog'] button"));
                        for (var c of confs) {
                            var txt = (c.innerText || '').trim().toLowerCase();
                            if (txt === 'delete' || txt === 'confirm') {
                                c.click();
                                break;
                            }
                        }
                    """)
                    time.sleep(1.5)
                else:
                    break

            # 3. Click 'Create new' to guarantee a fresh blank pin canvas
            create_new_btns = driver.find_elements(By.XPATH, "//button[contains(., 'Create new') or contains(., 'Create New')]")
            for b in create_new_btns:
                if b.is_displayed():
                    log("Found 'Create new' button — clicking to guarantee fresh pin canvas...")
                    driver.execute_script("arguments[0].click();", b)
                    time.sleep(2)
                    break
        except Exception as e_draft:
            log(f"Draft purge notice: {e_draft}")
        
        log("Pin builder ready")

        # ── Step 3: Upload image ───────────────────────────────────
        def is_valid_file(p):
            try:
                return bool(p and os.path.exists(p) and os.path.getsize(p) > 50)
            except Exception:
                return False

        real_image_path = image_path
        if not is_valid_file(real_image_path):
            uploads_dir = "/var/www/html/uploads"
            if os.path.exists(uploads_dir):
                for f in os.listdir(uploads_dir):
                    if f.lower().endswith(('.jpg', '.jpeg', '.png', '.webp')):
                        candidate = os.path.join(uploads_dir, f)
                        if is_valid_file(candidate):
                            real_image_path = candidate
                            log(f"Found fallback image in uploads: {real_image_path}")
                            break

        if not is_valid_file(real_image_path):
            try:
                fallback_file = "/tmp/pinterest_fallback_pin.bmp"
                w, h = 800, 1200
                f_hdr = b'BM' + (54 + w * h * 3).to_bytes(4, 'little') + (0).to_bytes(4, 'little') + (54).to_bytes(4, 'little')
                i_hdr = (40).to_bytes(4, 'little') + w.to_bytes(4, 'little') + h.to_bytes(4, 'little') + (1).to_bytes(2, 'little') + (24).to_bytes(2, 'little') + (0).to_bytes(24, 'little')
                pix = b'\xe6\x7d\x1e' * (w * h)
                with open(fallback_file, 'wb') as f_out:
                    f_out.write(f_hdr + i_hdr + pix)
                if is_valid_file(fallback_file):
                    real_image_path = fallback_file
                    log(f"Generated local fallback Pin image: {fallback_file}")
            except Exception as e_gen:
                log(f"Local image gen error: {e_gen}")

        def prepare_optimized_image(img_path):
            if not img_path or not os.path.exists(img_path):
                return img_path
            try:
                from PIL import Image
                opt_path = os.path.join(os.path.dirname(os.path.abspath(img_path)), f"opt_{int(time.time())}.jpg")
                with Image.open(img_path) as im:
                    im = im.convert("RGB")
                    im.save(opt_path, "JPEG", quality=90, optimize=True)
                if os.path.exists(opt_path) and os.path.getsize(opt_path) > 100:
                    log(f"Optimized upload image size: {os.path.getsize(opt_path)//1024} KB")
                    return opt_path
            except Exception as e_opt:
                log(f"Image optimize note: {e_opt}")
            return img_path

        real_image_path = prepare_optimized_image(real_image_path)

        image_uploaded = False
        if is_valid_file(real_image_path):
            log(f"Uploading image: {real_image_path}...")
            try:
                up = None
                file_inputs = driver.find_elements(By.CSS_SELECTOR, "input[type='file']")
                if file_inputs:
                    up = file_inputs[0]
                else:
                    try:
                        up = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "input[data-test-id='storyboard-upload-input']")))
                    except Exception:
                        pass
                if up:
                    driver.execute_script("arguments[0].style.display='block'; arguments[0].style.opacity='1'; arguments[0].style.visibility='visible';", up)
                    up.send_keys(os.path.abspath(real_image_path))
                    time.sleep(6)
                    log("Image uploaded!")
                    image_uploaded = True
            except Exception as e:
                log(f"Image upload: {e}")
        else:
            log("No valid image file found for Pin upload!")

        # ── Step 4: Title ──────────────────────────────────────────
        title = ai_title if ai_title else f"Best {keyword.title()} - {time.strftime('%Y')} Guide"
        log("Filling title...")
        try:
            title_filled = driver.execute_script("""
                var val = arguments[0];
                var sel = "[data-test-id='pin-builder-title'] input, [data-test-id='pin-builder-title'] textarea, #storyboard-selector-title, [data-test-id='storyboard-selector-title']";
                var el = document.querySelector(sel);
                if (!el) {
                    var inps = Array.from(document.querySelectorAll('input, textarea'));
                    el = inps.find(function(i) {
                        var ph = (i.getAttribute('placeholder') || '').toLowerCase();
                        var id = (i.getAttribute('id') || '').toLowerCase();
                        var name = (i.getAttribute('name') || '').toLowerCase();
                        var aria = (i.getAttribute('aria-label') || '').toLowerCase();
                        return ph.indexOf('title') !== -1 || id.indexOf('title') !== -1 || name.indexOf('title') !== -1 || aria.indexOf('title') !== -1;
                    });
                }
                if (el) {
                    el.focus();
                    el.scrollIntoView({block: 'center'});
                    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                        var proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
                        var setter = Object.getOwnPropertyDescriptor(proto, 'value');
                        if (setter && setter.set) setter.set.call(el, val); else el.value = val;
                    } else {
                        try { el.innerText = val; } catch(e) { el.textContent = val; }
                    }
                    el.dispatchEvent(new Event('input', {bubbles: true, composed: true}));
                    el.dispatchEvent(new Event('change', {bubbles: true, composed: true}));
                    return true;
                }
                return false;
            """, title[:100])
            if title_filled:
                log("Title OK!")
            else:
                log("Title element not found via selectors")
        except Exception as e:
            log(f"Title: {e}")

        # ── Step 5: Description ────────────────────────────────────
        if ai_content and len(ai_content.strip()) > 10:
            desc = ai_content.strip()
        else:
            desc = (
                f"Looking for the best {keyword}? Learnmore Technologies offers expert-led "
                f"{keyword} with hands-on live projects, industry-recognized certification, "
                f"and 100% placement support. Our {keyword} covers all key concepts from "
                f"beginner to advanced level. Join hundreds of successful students who built "
                f"their IT careers with us. Flexible batch timings, experienced trainers, "
                f"small batches for personal attention. "
                f"Enroll now at {target_site} — Limited seats available! "
                f"#{keyword.replace(' ','')} #Training #Bangalore #Career #Education #Certification"
            )
        desc = desc[:500]
        log(f"Description length: {len(desc)} chars")
        log("Filling description via DraftJS OS Clipboard handler...")
        try:
            filled = fill_draftjs_editor(driver, desc)
            if filled:
                log("Description filled and DraftJS state confirmed!")
            else:
                log("Description fill returned False")
        except Exception as e:
            log(f"Desc error: {e}")

        # ── Step 6: Link ───────────────────────────────────────────
        log("Filling link...")
        try:
            link_filled = driver.execute_script("""
                var val = arguments[0];
                var sel = "[data-test-id='pin-builder-link'] input, [data-test-id='pin-builder-link'] textarea, #storyboard-selector-link, input[id='WebsiteField'], input[name='link']";
                var el = document.querySelector(sel);
                if (!el) {
                    var inps = Array.from(document.querySelectorAll('input, textarea'));
                    el = inps.find(function(i) {
                        var ph = (i.getAttribute('placeholder') || '').toLowerCase();
                        var id = (i.getAttribute('id') || '').toLowerCase();
                        var name = (i.getAttribute('name') || '').toLowerCase();
                        var aria = (i.getAttribute('aria-label') || '').toLowerCase();
                        return ph.indexOf('link') !== -1 || ph.indexOf('destination') !== -1 || ph.indexOf('website') !== -1 || id.indexOf('link') !== -1 || id.indexOf('website') !== -1 || name.indexOf('link') !== -1;
                    });
                }
                if (el) {
                    el.focus();
                    el.scrollIntoView({block: 'center'});
                    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                        var proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
                        var setter = Object.getOwnPropertyDescriptor(proto, 'value');
                        if (setter && setter.set) setter.set.call(el, val); else el.value = val;
                    } else {
                        try { el.innerText = val; } catch(e) { el.textContent = val; }
                    }
                    el.dispatchEvent(new Event('input', {bubbles: true, composed: true}));
                    el.dispatchEvent(new Event('change', {bubbles: true, composed: true}));
                    return true;
                }
                return false;
            """, target_site)
            if link_filled:
                log("Link OK!")
            else:
                log("Link element not found via selectors")
        except Exception as e:
            log(f"Link: {e}")

        # ── Step 7: Board ──────────────────────────────────────────
        log("Opening board dropdown...")
        board_selected = False

        try:
            bb = None
            board_selectors = [
                "[data-test-id='board-dropdown-select-button']",
                "button[aria-label*='board' i]",
                "button[aria-label*='Board' i]",
                "[data-test-id='board-dropdown-select-button'] button",
                "div[data-test-id='board-dropdown']"
            ]
            for sel in board_selectors:
                try:
                    elems = driver.find_elements(By.CSS_SELECTOR, sel)
                    if elems and elems[0].is_displayed():
                        bb = elems[0]
                        break
                except Exception:
                    continue

            if bb:
                driver.execute_script("arguments[0].scrollIntoView({block:'center'});", bb)
                time.sleep(0.5)
                js_click(driver, bb)
                time.sleep(2)
                log("Board dropdown opened")

            # Check for existing boards — select available board via synthetic events
            board_selected = driver.execute_script("""
                var options = Array.from(document.querySelectorAll('[data-test-id="boardWithoutSection"], [data-test-id="board-row"], div[role="option"], div[role="button"]'));
                var validOption = options.find(function(el) {
                    var t = (el.innerText || el.textContent || '').trim().toLowerCase();
                    return t && !t.includes('create') && !t.includes('search') && !t.includes('all boards');
                });
                if (!validOption) {
                    var allDivs = Array.from(document.querySelectorAll('div'));
                    validOption = allDivs.find(function(el) {
                        var t = (el.innerText || el.textContent || '').trim();
                        return t.length > 0 && t.length < 40 && t !== 'PROPATY' && (t.indexOf('PROPATY') !== -1 || el.getAttribute('title') === 'PROPATY');
                    }) || allDivs.find(function(el) {
                        var t = (el.innerText || el.textContent || '').trim().toLowerCase();
                        return el.children.length === 0 && t.length > 1 && t.length < 40 && !t.includes('create') && !t.includes('search') && !t.includes('title') && !t.includes('board');
                    });
                }
                if (validOption) {
                    validOption.scrollIntoView({block: 'center'});
                    ['mousedown', 'mouseup', 'click'].forEach(function(evtName) {
                        var evt = new MouseEvent(evtName, { bubbles: true, cancelable: true, view: window });
                        validOption.dispatchEvent(evt);
                    });
                    return true;
                }
                return false;
            """)

            if board_selected:
                time.sleep(2)
                log("Board selected via JS synthetic mouse events!")
            else:
                log("No existing board clicked — checking python rows...")
                rows = driver.find_elements(By.CSS_SELECTOR, "[data-test-id='boardWithoutSection'], [data-test-id='board-row'], div[role='option']")
                if rows:
                    for r in rows:
                        txt = (r.text or '').strip().lower()
                        if txt and 'create' not in txt:
                            js_click(driver, r)
                            time.sleep(2)
                            log(f"Board selected via selenium click: '{txt[:60]}'")
                            board_selected = True
                            break

            if not board_selected:
                log("No existing boards — creating new...")

                # Click create board
                cb = wait.until(EC.element_to_be_clickable(
                    (By.CSS_SELECTOR, "[data-test-id='create-board-button']")))
                js_click(driver, cb)
                time.sleep(3)
                log("Create board modal opened")

                board_name = f"{keyword.title()} Training"
                board_name_set = False

                SKIP_IDS = {
                    'search-input', 'WebsiteField',
                    'storyboard-selector-title',
                    'combobox-storyboard-interest-tags',
                }

                all_inputs = driver.find_elements(By.TAG_NAME, "input")

                for inp in all_inputs:
                    try:
                        inp_id   = inp.get_attribute('id') or ''
                        inp_ph   = inp.get_attribute('placeholder') or ''
                        inp_type = inp.get_attribute('type') or 'text'
                        if inp_type in ('file', 'checkbox', 'hidden', 'url'):
                            continue
                        if inp_id in SKIP_IDS:
                            continue
                        if 'search' in inp_id.lower() or 'search' in inp_ph.lower():
                            continue
                        if not inp.is_displayed():
                            continue

                        driver.execute_script("arguments[0].scrollIntoView({block:'center'});", inp)
                        time.sleep(0.3)
                        ActionChains(driver).move_to_element(inp).click().perform()
                        time.sleep(0.3)
                        inp.send_keys(board_name)
                        time.sleep(0.4)
                        actual = inp.get_attribute('value') or ''
                        if actual:
                            board_name_set = True
                            break
                        else:
                            js_set_value(driver, inp, board_name)
                            time.sleep(0.3)
                            actual2 = inp.get_attribute('value') or ''
                            if actual2:
                                board_name_set = True
                                break
                    except Exception as e:
                        log(f"  input try: {e}")

                if not board_name_set:
                    try:
                        driver.execute_script(
                            "document.querySelector('[data-test-id=\"board-form-container\"]').querySelector('input').focus();"
                        )
                        time.sleep(0.3)
                        driver.switch_to.active_element.send_keys(board_name)
                        time.sleep(0.3)
                        board_name_set = True
                    except Exception as e:
                        log(f"Active element: {e}")

                time.sleep(1)

                try:
                    sbmt = wait.until(EC.element_to_be_clickable(
                        (By.CSS_SELECTOR, "[data-test-id='board-form-submit-button']")))
                    js_click(driver, sbmt)
                    time.sleep(5)
                    log("Board created via board-form-submit-button!")
                    board_selected = True
                except Exception as e:
                    log(f"board-form-submit: {e}")
                    for btn in driver.find_elements(By.TAG_NAME, "button"):
                        if btn.text.strip() in ("Create", "Create board") and btn.is_displayed():
                            js_click(driver, btn)
                            time.sleep(5)
                            log(f"Board created via '{btn.text}' btn!")
                            board_selected = True
                            break

        except Exception as e:
            log(f"Board section: {e}")

        # Close popovers
        try:
            ActionChains(driver).send_keys(Keys.ESCAPE).perform()
            time.sleep(1)
        except Exception:
            pass

        # ── Step 8: Publish ────────────────────────────────────────
        log("Publishing pin...")
        time.sleep(2)
        try:
            driver.save_screenshot(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'before_publish.png'))
            log("Saved Pin Builder state screenshot to before_publish.png")
        except Exception:
            pass
        published = False

        # Try exact JS click on Pinterest Publish/Save button
        try:
            click_success = driver.execute_script("""
                var pubBtn = document.querySelector("[data-test-id='board-dropdown-save-button'], [data-test-id='storyboard-creation-nav-save-button'], [data-test-id='pin-builder-publish-button'], [data-test-id='publish-button']");
                if (!pubBtn) {
                    var btns = Array.from(document.querySelectorAll('button'));
                    pubBtn = btns.find(function(b) {
                        var t = (b.innerText || b.textContent || '').trim().toLowerCase();
                        var dt = (b.getAttribute('data-test-id') || '').toLowerCase();
                        return (t === 'publish' || t === 'save' || t === 'done' || dt.indexOf('save-button') !== -1 || dt.indexOf('publish') !== -1);
                    });
                }
                if (pubBtn) {
                    pubBtn.disabled = false;
                    pubBtn.removeAttribute('disabled');
                    pubBtn.scrollIntoView({block: 'center'});
                    ['mousedown', 'mouseup', 'click'].forEach(function(evtName) {
                        var evt = new MouseEvent(evtName, { bubbles: true, cancelable: true, view: window });
                        pubBtn.dispatchEvent(evt);
                    });
                    try { pubBtn.click(); } catch(e) {}
                    var form = pubBtn.closest('form');
                    if (form) { try { form.dispatchEvent(new Event('submit', {bubbles: true, cancelable: true})); } catch(e) {} }
                    return true;
                }
                return false;
            """)
            if click_success:
                log("Clicked Publish button via JS synthetic mouse events!")
                published = True
        except Exception as e_js_pub:
            log(f"JS publish click note: {e_js_pub}")

        if not published:
            pub_selectors = [
                "[data-test-id='board-dropdown-save-button']",
                "[data-test-id='storyboard-creation-nav-save-button']",
                "[data-test-id='pin-builder-publish-button']",
                "[data-test-id='publish-button']"
            ]
            for sel in pub_selectors:
                try:
                    elems = driver.find_elements(By.CSS_SELECTOR, sel)
                    for el in elems:
                        if el and el.is_displayed():
                            js_click(driver, el)
                            log(f"Published via selector '{sel}'!")
                            published = True
                            break
                    if published:
                        break
                except Exception:
                    pass

        # ── Step 9: Monitor Pin Creation & Extract URL ────────────
        log("Checking for Pin creation confirmation...")
        pin_url_found = None

        for i in range(40): # Poll every 0.5s for 20s immediately after publish
            cu = (driver.current_url or '').lower()
            if "/pin/" in cu and "/pin-builder" not in cu:
                pin_url_found = driver.current_url
                log(f"Pin created successfully (URL redirect)! URL: {pin_url_found}")
                break

            # Search DOM for created Pin link or toast element
            try:
                found_link = driver.execute_script("""
                    var sel = "a[href*='/pin/'], div[role='alert'] a, div[data-test-id*='toast'] a, div[aria-label*='toast' i] a, button[aria-label*='Pin' i] a";
                    var elems = Array.from(document.querySelectorAll(sel));
                    for (var el of elems) {
                        var href = el.getAttribute('href') || el.href || '';
                        if (href && href.indexOf('/pin/') !== -1 && href.indexOf('/pin-builder') === -1) {
                            return href;
                        }
                    }
                    return null;
                """)
                if found_link:
                    if not found_link.startswith('http'):
                        found_link = f"https://www.pinterest.com{found_link}"
                    pin_url_found = found_link
                    log(f"Pin created successfully (toast/DOM link)! URL: {pin_url_found}")
                    break
            except Exception as e_link:
                log(f"DOM link check note: {e_link}")

            # Check page source for /pin/123456789
            try:
                page = driver.page_source
                pin_ids = re.findall(r'/pin/(\d{10,20})', page)
                if pin_ids:
                    pin_url_found = f"https://www.pinterest.com/pin/{pin_ids[0]}/"
                    log(f"Pin created successfully (page source ID)! URL: {pin_url_found}")
                    break
            except Exception:
                pass

            time.sleep(0.5)

        # Fallback check: If URL not found via toast or current_url within 20s, navigate to user profile created pins!
        if not pin_url_found:
            log("Pin toast URL not found in 20s — navigating to profile created pins to fetch newly published Pin URL...")
            try:
                driver.get("https://www.pinterest.com/me/")
                time.sleep(4)
                profile_link = driver.execute_script("""
                    var elems = Array.from(document.querySelectorAll("a[href*='/pin/']"));
                    for (var el of elems) {
                        var href = el.getAttribute('href') || el.href || '';
                        if (href && href.indexOf('/pin/') !== -1 && href.indexOf('/pin-builder') === -1) {
                            return href;
                        }
                    }
                    return null;
                """)
                if profile_link:
                    if not profile_link.startswith('http'):
                        profile_link = f"https://www.pinterest.com{profile_link}"
                    pin_url_found = profile_link
                    log(f"Pin created successfully (profile check)! URL: {pin_url_found}")
                else:
                    page = driver.page_source
                    pin_ids = re.findall(r'/pin/(\d{10,20})', page)
                    if pin_ids:
                        pin_url_found = f"https://www.pinterest.com/pin/{pin_ids[0]}/"
                        log(f"Pin created successfully (profile page source)! URL: {pin_url_found}")
            except Exception as e_prof:
                log(f"Profile check error: {e_prof}")

        if pin_url_found:
            time.sleep(3) # Let Pinterest finalize background draft cleanup
            result(True, url=pin_url_found)
            return
        else:
            result(False, error="Pin creation could not be verified on Pinterest. Please check if Pinterest requested board selection, title, or captcha.")


    except Exception as e:
        try:
            driver.save_screenshot(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'pinterest_error.png'))
            log("Saved exception error screenshot to pinterest_error.png")
        except Exception as ex:
            log(f"Screenshot exception: {ex}")
        result(False, error=str(e))
    finally:
        try:
            driver.quit()
        except:
            pass

if __name__ == "__main__":
    if len(sys.argv) < 5:
        result(False, error="Usage: pinterest_post.py <email> <password> <keyword> <target_site> [image_path] [ai_title] [ai_content] [proxy]")
        sys.exit(1)
    pinterest_post(
        sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4],
        sys.argv[5] if len(sys.argv) > 5 else None,
        sys.argv[6] if len(sys.argv) > 6 else "",
        sys.argv[7] if len(sys.argv) > 7 else "",
        sys.argv[8] if len(sys.argv) > 8 else None,
    )
